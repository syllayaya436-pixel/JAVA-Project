package JAVA_finalProject;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

/** Planificateur : déroule la saison semaine par semaine. */
public class Planner {
    private static final int FREEZING = 32;       // °F : en dessous ou égal, pas de match
    private static final int MAX_FROZEN_WEEKS = 3;

    private Team[] teams;
    private ArrayList<Game> games;
    private int frozenWeeks;
    private Random random;
    private Database database;

    public Planner(Database database) {
        this.database = database;
        this.teams = new Team[4];
        for (int i = 0; i < teams.length; i++) {
            teams[i] = new Team("Equipe " + (i + 1));
        }
        this.games = new ArrayList<>();
        this.random = new Random();
        this.frozenWeeks = 0;
    }

    public Team[] getTeams() { return teams; }
    public ArrayList<Game> getGames() { return games; }
    public int getFrozenWeeks() { return frozenWeeks; }
    public void setFrozenWeeks(int frozenWeeks) { this.frozenWeeks = frozenWeeks; }

    /** Boucle principale de la saison. */
    public void runSeason() {
        Scanner scanner = new Scanner(System.in);
        while (frozenWeeks < MAX_FROZEN_WEEKS) {
            System.out.print("Entrez la température de la semaine (°F) : ");
            if (!scanner.hasNextLine()) {
                break; // fin de l'entrée : on arrête proprement
            }
            String line = scanner.nextLine().trim();
            int temperature;
            try {
                temperature = Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Entrée invalide, veuillez saisir un nombre entier.");
                continue;
            }

            if (temperature <= FREEZING) {
                System.out.println("Too cold to play.");
                frozenWeeks++;
            } else {
                frozenWeeks = 0;
                playWeek(temperature);
            }
        }
        System.out.println("Season is over");
        printResults();
        saveToDatabase();
    }

    /** Joue 2 matchs avec des adversaires tirés au hasard (une équipe ne s'affronte jamais elle-même). */
    private void playWeek(int temperature) {
        ArrayList<Integer> order = new ArrayList<>();
        for (int i = 0; i < teams.length; i++) order.add(i);
        Collections.shuffle(order, random);

        for (int m = 0; m < 2; m++) {
            Team home = teams[order.get(2 * m)];
            Team away = teams[order.get(2 * m + 1)];
            int maxGoals = Math.min(10, 1 + temperature / 15); // plus chaud = plus de buts, mais raisonnable
            int homeScore = random.nextInt(maxGoals + 1);
            int awayScore = random.nextInt(maxGoals + 1);

            home.recordMatch(homeScore, awayScore);
            away.recordMatch(awayScore, homeScore);
            games.add(new Game(home, away, homeScore, awayScore, temperature));
        }
    }

    public int getHottest() {
        int max = Integer.MIN_VALUE;
        for (Game g : games) max = Math.max(max, g.getTemperature());
        return games.isEmpty() ? 0 : max;
    }

    public double getAverageTemperature() {
        if (games.isEmpty()) return 0;
        double sum = 0;
        for (Game g : games) sum += g.getTemperature();
        return sum / games.size();
    }

    private void printResults() {
        System.out.println("\n\n*********RESULTATS*********\n");
        for (Team t : teams) {
            System.out.println(t + "\n");
        }
        for (Game g : games) {
            System.out.println(g + "\n");
        }
        System.out.println("Temp. la plus chaude : " + getHottest());
        System.out.println("Temp. moyenne : " + getAverageTemperature());
    }

    private void saveToDatabase() {
        if (database == null) return;
        try {
            int id = database.saveSeason(teams, games, getHottest(), getAverageTemperature());
            System.out.println("\nSaison enregistrée dans la base de données (id " + id + ").");
            database.printHistory();
        } catch (SQLException e) {
            System.out.println("\nImpossible d'enregistrer la saison : " + e.getMessage());
        }
    }
}
