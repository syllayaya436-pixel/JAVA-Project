package JAVA_finalProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/** Accès à la base MariaDB : création des tables et sauvegarde d'une saison. */
public class Database {
    private static final String URL =
        System.getenv().getOrDefault("DB_URL", "jdbc:mariadb://localhost:3306/football");
    private static final String USER =
        System.getenv().getOrDefault("DB_USER", "football_user");
    private static final String PASSWORD =
        System.getenv().getOrDefault("DB_PASSWORD", "football_pass");

    private Connection connection;

    public void connect() throws SQLException {
        connection = DriverManager.getConnection(URL, USER, PASSWORD);
        createTables();
    }

    public void close() {
        try {
            if (connection != null) connection.close();
        } catch (SQLException e) {
            System.out.println("Erreur à la fermeture de la base : " + e.getMessage());
        }
    }

    private void createTables() throws SQLException {
        try (Statement st = connection.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS season ("
                + "id INT AUTO_INCREMENT PRIMARY KEY,"
                + "played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
                + "hottest_temp INT NOT NULL,"
                + "average_temp DOUBLE NOT NULL)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS team_stats ("
                + "id INT AUTO_INCREMENT PRIMARY KEY,"
                + "season_id INT NOT NULL,"
                + "name VARCHAR(50) NOT NULL,"
                + "wins INT NOT NULL, losses INT NOT NULL, draws INT NOT NULL,"
                + "goals_for INT NOT NULL, goals_against INT NOT NULL,"
                + "FOREIGN KEY (season_id) REFERENCES season(id) ON DELETE CASCADE)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS game ("
                + "id INT AUTO_INCREMENT PRIMARY KEY,"
                + "season_id INT NOT NULL,"
                + "game_number INT NOT NULL,"
                + "home_team VARCHAR(50) NOT NULL, away_team VARCHAR(50) NOT NULL,"
                + "home_score INT NOT NULL, away_score INT NOT NULL,"
                + "temperature INT NOT NULL,"
                + "FOREIGN KEY (season_id) REFERENCES season(id) ON DELETE CASCADE)");
        }
    }

    /** Enregistre une saison complète (transaction : tout ou rien). */
    public int saveSeason(Team[] teams, ArrayList<Game> games, int hottest, double average)
            throws SQLException {
        connection.setAutoCommit(false);
        try {
            int seasonId;
            try (PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO season (hottest_temp, average_temp) VALUES (?, ?)",
                    Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, hottest);
                ps.setDouble(2, average);
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    keys.next();
                    seasonId = keys.getInt(1);
                }
            }

            try (PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO team_stats (season_id, name, wins, losses, draws, goals_for, goals_against) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)")) {
                for (Team t : teams) {
                    ps.setInt(1, seasonId);
                    ps.setString(2, t.getName());
                    ps.setInt(3, t.getWins());
                    ps.setInt(4, t.getLosses());
                    ps.setInt(5, t.getDraws());
                    ps.setInt(6, t.getGoalsFor());
                    ps.setInt(7, t.getGoalsAgainst());
                    ps.executeUpdate();
                }
            }

            try (PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO game (season_id, game_number, home_team, away_team, "
                    + "home_score, away_score, temperature) VALUES (?, ?, ?, ?, ?, ?, ?)")) {
                for (Game g : games) {
                    ps.setInt(1, seasonId);
                    ps.setInt(2, g.getId());
                    ps.setString(3, g.getHomeTeam().getName());
                    ps.setString(4, g.getAwayTeam().getName());
                    ps.setInt(5, g.getHomeScore());
                    ps.setInt(6, g.getAwayScore());
                    ps.setInt(7, g.getTemperature());
                    ps.executeUpdate();
                }
            }

            connection.commit();
            return seasonId;
        } catch (SQLException e) {
            connection.rollback();
            throw e;
        } finally {
            connection.setAutoCommit(true);
        }
    }

    /** Affiche l'historique des saisons déjà enregistrées. */
    public void printHistory() throws SQLException {
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery(
                 "SELECT s.id, s.played_at, s.hottest_temp, s.average_temp, COUNT(g.id) AS nb "
                 + "FROM season s LEFT JOIN game g ON g.season_id = s.id "
                 + "GROUP BY s.id ORDER BY s.id")) {
            System.out.println("\n*********HISTORIQUE DES SAISONS*********");
            while (rs.next()) {
                System.out.println("Saison " + rs.getInt("id") + " (" + rs.getTimestamp("played_at")
                    + ") : " + rs.getInt("nb") + " matchs, temp. max " + rs.getInt("hottest_temp")
                    + ", temp. moyenne " + rs.getDouble("average_temp"));
            }
        }
    }
}
