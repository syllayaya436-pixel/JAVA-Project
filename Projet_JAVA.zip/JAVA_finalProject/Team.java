package JAVA_finalProject;

/** Une équipe du championnat et ses statistiques. */
public class Team {
    private String name;
    private int wins;
    private int losses;
    private int draws;
    private int goalsFor;
    private int goalsAgainst;

    public Team(String name) {
        this.name = name;
    }

    /** Met à jour les statistiques après un match. */
    public void recordMatch(int scored, int conceded) {
        goalsFor += scored;
        goalsAgainst += conceded;
        if (scored > conceded) {
            wins++;
        } else if (scored < conceded) {
            losses++;
        } else {
            draws++;
        }
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getWins() { return wins; }
    public void setWins(int wins) { this.wins = wins; }
    public int getLosses() { return losses; }
    public void setLosses(int losses) { this.losses = losses; }
    public int getDraws() { return draws; }
    public void setDraws(int draws) { this.draws = draws; }
    public int getGoalsFor() { return goalsFor; }
    public void setGoalsFor(int goalsFor) { this.goalsFor = goalsFor; }
    public int getGoalsAgainst() { return goalsAgainst; }
    public void setGoalsAgainst(int goalsAgainst) { this.goalsAgainst = goalsAgainst; }

    @Override
    public String toString() {
        return name + "\n"
            + "Victoires : " + wins + ", Défaites : " + losses + ", Matchs nuls : " + draws + "\n"
            + "Points marqués : " + goalsFor + ", Points concédés : " + goalsAgainst;
    }
}
