package JAVA_finalProject;

/** Un match joué entre deux équipes. */
public class Game {
    private static int counter = 0;

    private int id;
    private Team homeTeam;
    private Team awayTeam;
    private int homeScore;
    private int awayScore;
    private int temperature;

    public Game(Team homeTeam, Team awayTeam, int homeScore, int awayScore, int temperature) {
        this.id = ++counter;
        this.homeTeam = homeTeam;
        this.awayTeam = awayTeam;
        this.homeScore = homeScore;
        this.awayScore = awayScore;
        this.temperature = temperature;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public Team getHomeTeam() { return homeTeam; }
    public void setHomeTeam(Team homeTeam) { this.homeTeam = homeTeam; }
    public Team getAwayTeam() { return awayTeam; }
    public void setAwayTeam(Team awayTeam) { this.awayTeam = awayTeam; }
    public int getHomeScore() { return homeScore; }
    public void setHomeScore(int homeScore) { this.homeScore = homeScore; }
    public int getAwayScore() { return awayScore; }
    public void setAwayScore(int awayScore) { this.awayScore = awayScore; }
    public int getTemperature() { return temperature; }
    public void setTemperature(int temperature) { this.temperature = temperature; }

    @Override
    public String toString() {
        return "Match n° " + id + "\n"
            + "Température : " + temperature + "\n"
            + "Equipe à l'extérieur : " + awayTeam.getName() + ", " + awayScore + "\n"
            + "Equipe à domicile : " + homeTeam.getName() + ", " + homeScore;
    }
}
