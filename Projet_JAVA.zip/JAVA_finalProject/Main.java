package JAVA_finalProject;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        Database database = new Database();
        try {
            database.connect();
        } catch (SQLException e) {
            // Le programme fonctionne même sans base : on prévient simplement l'utilisateur.
            System.out.println("Base de données indisponible (" + e.getMessage()
                + "). La saison ne sera pas enregistrée.");
            database = null;
        }

        Planner planner = new Planner(database);
        planner.runSeason();

        if (database != null) database.close();
    }
}
