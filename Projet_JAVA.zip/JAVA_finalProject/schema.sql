-- À exécuter une seule fois : sudo mariadb < schema.sql
CREATE DATABASE IF NOT EXISTS football CHARACTER SET utf8mb4;
CREATE USER IF NOT EXISTS 'football_user'@'localhost' IDENTIFIED BY 'football_pass';
GRANT ALL PRIVILEGES ON football.* TO 'football_user'@'localhost';
FLUSH PRIVILEGES;
-- Les tables (season, team_stats, game) sont créées automatiquement par le programme.
